﻿app.controller('indexController', ['$scope', '$rootScope', '$location', '$cookies', function ($scope, $rootScope, $location, $cookies) {
    var self = this;
}]);